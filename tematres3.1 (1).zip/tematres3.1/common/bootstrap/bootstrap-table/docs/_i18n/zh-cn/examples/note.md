**Note:** All examples are based on [jsFiddle](http://jsfiddle.net/), you can add your great and representative examples by Edit on GitHub link.

---

